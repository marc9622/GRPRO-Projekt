Verdens 100 bedste film (iflg. �n imdb-liste) er gemt i filen film.txt. De st�r p� hver sin linje i formatet: titel; �rstal; kategori1, kategori2, ..; rating
Kategorierne er: Crime, Drama, Biography, Sport, History, Romance, War, Mystery, Adventure, Family, Fantasy, Thriller, Horror, Film-Noir, Action, Sci-fi, Comedy , Musical, Western og Music.
Tilh�rende filmplakater ligger i filen filmplakater.zip. De enkelte billeder er navngivet efter filmen.  
Billederne kan v�re (og er sikkert) beskyttet af copyright, s� lad dem blive indenfor vores lukkede kreds :-)

Verdens 100 bedste serier (igen iflg. en anden imdb-liste) er gemt i filen serier.txt. De st�r p� hver sin linje i formatet: titel; �rtalFra-�rstalTil; kategori1, kategori2, ..; rating; s�sonnummer-antalEpisoder, s�sonnummer-antalEpisoder...; 
Hvis serien stadig k�rer (eller gjorde det, da listen blev lavet) er der et �rstalFra og en bindestreg, men intet �rstalTil. Hvis serien kun k�rte i �t �r, er der et �rstalFra, men ingen bindestreg. 
Kategorierne er: Talk-show, Documentary, Crime, Drama, Action, Adventure, Drama, Comedy, Fantasy, Animation, Horror, Sci-fi, War, Thriller, Mystery, Biography, History, Family, Western, Romance og Sport.
Tilh�rende billeder ligger i filen serieforsider.zip. De enkelte billeder er navngivet efter serien.  
Billederne kan v�re (og er sikkert) beskyttet af copyright, s� lad dem blive indenfor vores lukkede kreds :-)